﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Citizen
{
    internal class Citizen
    {
        private string name;
        private string surname;
        private string date;
        private string place;
        private string pol;
        public Citizen(string name, string surname, string date, string place, string pol)
        {
            this.name = name;
            this.surname = surname;
            this.date = date;
            this.place = place;
            this.pol = pol;
        }
        public void SetName(string name)
        {
            this.name = name;
        }
        public string GetName()
        {
            return this.name;
        }
        public void SetSurname(string surname)
        {
            this.surname = surname;
        }
        public string GetSurname()
        {
            return this.surname;
        }
        public void SetDate(string date)
        {
            this.date = date;
        }
        public string GetDate()
        {
            return this.date;
        }
        public void SetPlace(string place)
        {
            this.place = place;
        }
        public string GetPlace()
        {
            return this.place;
        }
        public void SetPol(string pol)
        {
            this.pol = pol;
        }
        public string GetPol()
        {
            return this.pol;
        }
    }
}
